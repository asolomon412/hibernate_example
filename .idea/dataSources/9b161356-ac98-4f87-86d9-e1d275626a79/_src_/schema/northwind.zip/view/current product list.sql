CREATE VIEW `current product list` AS
