CREATE VIEW `products above average price` AS
