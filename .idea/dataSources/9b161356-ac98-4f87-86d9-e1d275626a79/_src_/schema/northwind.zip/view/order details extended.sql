CREATE VIEW `order details extended` AS
