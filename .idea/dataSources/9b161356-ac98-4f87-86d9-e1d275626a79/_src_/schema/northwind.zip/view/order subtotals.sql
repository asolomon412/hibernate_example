CREATE VIEW `order subtotals` AS
