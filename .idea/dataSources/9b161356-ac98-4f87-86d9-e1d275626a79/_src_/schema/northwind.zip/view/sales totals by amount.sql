CREATE VIEW `sales totals by amount` AS
