CREATE VIEW `quarterly orders` AS
